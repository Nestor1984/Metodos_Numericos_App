package metodos;

public class porcentual {
    
}
