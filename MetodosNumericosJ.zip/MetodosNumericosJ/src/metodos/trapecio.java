package metodos;

import org.nfunk.jep.JEP;

public class trapecio {

    public String metodoTrapecio(String a1, String b1, String fx1, String intervalos1) {
        String mensaje = "Datos erróneos o incompletos";
        try {
            String expresion = fx1;

            JEP a2 = new JEP();
            a2.addStandardFunctions();//adiciona las fuciones matemáticas
            a2.addStandardConstants();
            a2.parseExpression(a1);//conversión de la expresión que se evaluará
            double a = a2.getValue();

            JEP b2 = new JEP();
            b2.addStandardFunctions();
            b2.addStandardConstants();
            b2.parseExpression(b1); //conversión de la expresión a evaluar
            double b = b2.getValue();

            int n = Integer.parseInt(intervalos1); //numero de intervalos

            double h = (b - a) / n;
            int m = (int) n;

            double x[] = new double[m + 1];
            x[0] = a;

            for (int i = 1; i < x.length; i++) {
                x[i] = x[0] + (i * h); //bucle para calcular el término xi
            }

            JEP funcion = new JEP();
            funcion.addStandardFunctions();;
            funcion.addStandardConstants();
            funcion.setImplicitMul(true);

            double fi[] = new double[m + 1]; //calcula el valor del polinomio en el punto xi
            for (int i = m; i >= 0; i--) {
                for (int j = fi.length - 1; j > 0; j--) {
                    fi[i] = funcion.addVariable("x", x[i]);
                    funcion.parseExpression(expresion); //conversión de la expresión a evaluar
                    fi[i] = funcion.getValue();
                }
            }

            double integral = 0;
            for (int i = 1; i < m; i++) {
                integral = integral + (2 * fi[i]);
            }
            integral = integral+fi[0]+fi[m];
            integral=(h/2)*integral;
            
            mensaje=Double.toString(integral);

        } catch (Exception e) {
            mensaje = "Datos erróneos o incompletos";

        }

        return mensaje;
    }
}
