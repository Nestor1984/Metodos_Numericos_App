package metodos;

import org.nfunk.jep.JEP;

public class v_real {

    public String valor_real(String a1, String b1, String fx1) {
        String mensaje = "Datos erróneos o incompletos";
        try {
            String expresion = fx1;

            JEP a2 = new JEP();
            a2.addStandardFunctions();//adiciona las fuciones matemáticas
            a2.addStandardConstants();
            a2.parseExpression(a1);//conversión de la expresión que se evaluará
            double a = a2.getValue();

            JEP b2 = new JEP();
            b2.addStandardFunctions();
            b2.addStandardConstants();
            b2.parseExpression(b1); //conversión de la expresión a evaluar
            double b = b2.getValue();
            
            JEP funcionEnA = new JEP();
            funcionEnA.addStandardFunctions();;
            funcionEnA.addStandardConstants();
            funcionEnA.setImplicitMul(true);
            
            JEP funcionEnB = new JEP();
            funcionEnB.addStandardFunctions();;
            funcionEnB.addStandardConstants();
            funcionEnB.setImplicitMul(true);
            
            double fa = funcionEnA.addVariable("x", a);
            funcionEnA.parseExpression(expresion);
            fa = funcionEnA.getValue();
            
            double fb = funcionEnB.addVariable("x", b);
            funcionEnB.parseExpression(expresion);
            fb = funcionEnB.getValue();
            
            double valor_real = (fb-fa);

            mensaje = Double.toString(valor_real);
            
            
        } catch (Exception e) {
            mensaje = "Datos erróneos o incompletos";
        }
        return mensaje;
    }
}
