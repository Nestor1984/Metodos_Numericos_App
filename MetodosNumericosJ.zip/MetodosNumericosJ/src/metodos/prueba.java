package metodos;
import org.nfunk.jep.JEP;
public class prueba {

    public static void main(String[] args) {
        String expresion = "(x^3)/3";

            JEP a2 = new JEP();
            a2.addStandardFunctions();//adiciona las fuciones matemáticas
            a2.addStandardConstants();
            a2.parseExpression("-3");//conversión de la expresión que se evaluará
            double a = a2.getValue();

            JEP b2 = new JEP();
            b2.addStandardFunctions();
            b2.addStandardConstants();
            b2.parseExpression("2"); //conversión de la expresión a evaluar
            double b = b2.getValue();
            
            JEP funcionEnA = new JEP();
            funcionEnA.addStandardFunctions();;
            funcionEnA.addStandardConstants();
            funcionEnA.setImplicitMul(true);
            
            JEP funcionEnB = new JEP();
            funcionEnB.addStandardFunctions();;
            funcionEnB.addStandardConstants();
            funcionEnB.setImplicitMul(true);
            
            double fa = funcionEnA.addVariable("x", a);
            funcionEnA.parseExpression(expresion);
            fa = funcionEnA.getValue();
            System.out.println("Funcion evaluada en A "+fa);
            
            double fb = funcionEnB.addVariable("x", b);
            funcionEnB.parseExpression(expresion);
            fb = funcionEnB.getValue();
            System.out.println("Funcion evaluada en B "+fb);
            
            double valor_real = (fb-fa);
            System.out.println("Valor real "+ valor_real);
    }
    
}
