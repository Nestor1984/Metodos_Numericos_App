package metodos;

import org.nfunk.jep.JEP;

public class simpson13 {

    public String simpson1_3(String a1, String b1, String fx1, String intervalos1) {
        String mensaje = "Datos erróneos o incompletos";

        try {
            String expresion = fx1;
            // 
            JEP a2 = new JEP();
            a2.addStandardFunctions(); // adiciona las funciones matemáticas
            a2.addStandardConstants();
            a2.parseExpression(a1); // paso de la expresión a evaluar
            double a = a2.getValue();

            JEP b2 = new JEP();
            b2.addStandardFunctions(); // adiciona las funciones matemáticas
            b2.addStandardConstants();
            b2.parseExpression(b1); // paso de la expresión a evaluar
            double b = b2.getValue();
            //

            int n = Integer.parseInt(intervalos1);// numero de intervalos
            if (n % 2 == 0) {
                double h = (b - a) / n;
                int m = (int) n;

                double x[] = new double[m + 1];
                x[0] = a;
                for (int i = 1; i < x.length; i++) {

                    x[i] = x[0] + (i * h);// calcula el termino Xi
                }

                JEP funcion = new JEP();
                funcion.addStandardFunctions(); // adiciona las funciones matemáticas
                funcion.addStandardConstants(); // adiciona las constantes matemáticas
                funcion.setImplicitMul(true);

                double fi[] = new double[m + 1];
                /*
                 * calcula el valor de el polinomio en el punto Xi
                 */
                for (int i = m; i >= 0; i--) {

                    for (int j = fi.length - 1; j > 0; j--) {
                        fi[i] = funcion.addVariable("x", x[i]);
                        funcion.parseExpression(expresion); // paso de la expresión a evaluar
                        fi[i] = funcion.getValue();
                    }

                }

                double integral1 = 0;
                double integral2 = 0;
                double integral;

                for (int i = 1; i < n; i++) {
                    if (i % 2 != 0) {
                        integral1 = integral1 + (4 * fi[i]);
                    }
                    if (i % 2 == 0) {
                        integral2 = integral2 + (2 * fi[i]);
                    }

                }
                integral = integral1 + integral2 + fi[0] + fi[m];
                integral = integral * (h / 3);
                mensaje = Double.toString(integral);
            }// fin if

            if (n % 2 != 0) {
                mensaje = "Número de intervalos impar ";
            }// fin else 

        }// fin try
        catch (NumberFormatException e) {
            mensaje = "Datos erróneos o incompletos";
        }

        return mensaje;

    }
}
